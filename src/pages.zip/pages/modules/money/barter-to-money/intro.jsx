import BarterToMoney from '../barter-to-money.jsx';

// Re-export the main component for the intro view
export default BarterToMoney;
